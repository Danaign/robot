#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import rospy
import moveit_commander
from geometry_msgs.msg import Pose, Quaternion
from std_msgs.msg import String
import geometry_msgs.msg
from math import pi
import copy
import time
from moveit_commander import MoveGroupCommander
from tf.transformations import quaternion_from_euler

# Ορισμός της αρχικής θέσης του ρομπότ
INITIAL_POSITION = {
    'x': 1.18425,
    'y': 0.290699999951,
    'z': 0.0608499999404,
    'orientation': {
        'x': 3.38932338369e-12,
        'y': 0.707106781259,
        'z': 0.707106781114,
        'w': 7.30837588403e-14
    }
}

# Ορισμός της θέσης υφάσματος
FABRIC_POSITION = {
    'x': 0.5,
    'y': 0.5,
    'z': 0.2,
    'orientation': {
        'roll': 0.0,
        'pitch': pi,  # 180 μοίρες σε ραδιανά για τον άξονα pitch (y)
        'yaw': 0.0
    }
}

# Ορισμός των κινηματικών ομάδων
move_group = None
hand_command_pub = None

def move_to_target(target_pose):
    global move_group
    if move_group is None:
        move_group = MoveGroupCommander("manipulator")

        # Μετατροπή των γωνιών Euler σε Quaternion
        quaternion = quaternion_from_euler(
            target_pose['orientation']['roll'],
            target_pose['orientation']['pitch'],
            target_pose['orientation']['yaw']
        )

    moved_pose = Pose()
    moved_pose.position.x = target_pose['x']
    moved_pose.position.y = target_pose['y']
    moved_pose.position.z = target_pose['z']


    # moved_pose.orientation = Quaternion(*quaternion)

    move_group.set_pose_target(moved_pose)
    plan = move_group.go(wait=True)
    move_group.stop()
    move_group.clear_pose_targets()

def move_home():
    global move_group
    if move_group is None:
        move_group = MoveGroupCommander("manipulator")
    group_name = move_group.get_name()
    rospy.loginfo("Moving {} to home position...".format(group_name))

    # Ορισμός της αρχικής θέσης
    pose_goal = geometry_msgs.msg.Pose()
    pose_goal.position.x = INITIAL_POSITION['x']
    pose_goal.position.y = INITIAL_POSITION['y']
    pose_goal.position.z = INITIAL_POSITION['z']
    pose_goal.orientation.x = INITIAL_POSITION['orientation']['x']
    pose_goal.orientation.y = INITIAL_POSITION['orientation']['y']
    pose_goal.orientation.z = INITIAL_POSITION['orientation']['z']
    pose_goal.orientation.w = INITIAL_POSITION['orientation']['w']

    move_group.set_pose_target(pose_goal)
    plan = move_group.go(wait=True)
    move_group.stop()
    move_group.clear_pose_targets()

    if plan:
        rospy.loginfo("Home position reached successfully for {}!".format(group_name))
    else:
        rospy.logerr("Failed to reach home position for {}.".format(group_name))

def move_danai(): # Σταθερή θέση υφάσματος
    global move_group, hand_command_pub
    if move_group is None:
        move_group = MoveGroupCommander("manipulator")

    rospy.loginfo("Moving manipulator to fabric position...")

    # Θέση υφάσματος
    fabric_pose = copy.deepcopy(FABRIC_POSITION)
    move_to_target(fabric_pose)


    # # Σταθερή θέση του υφάσματος
    # fabric_pose = copy.deepcopy(FABRIC_POSITION)
    # move_to_target(fabric_pose)

    hand_command_pub.publish("close")
    rospy.sleep(2)

    # Νέα θέση (μισό μέτρο δίπλα)
    moved_pose = copy.deepcopy(FABRIC_POSITION)
    moved_pose['x'] += 0.5
    move_to_target(moved_pose)


    # fabric_pose.position.x = FABRIC_POSITION['x']
    # fabric_pose.position.y = FABRIC_POSITION['y']
    # fabric_pose.position.z = FABRIC_POSITION['z']



    # Νέα θέση (μισό μέτρο δίπλα)
    # moved_pose = geometry_msgs.msg.Pose()

    # # Κλείσιμο του gripper
    # hand_command_pub.publish("close")
    # rospy.sleep(2)
    # # Νέα θέση (μισό μέτρο δίπλα)
    # moved_pose = geometry_msgs.msg.Pose()
    # moved_pose.orientation.w = 1.0
    # moved_pose.position.x = 0.5
    # moved_pose.position.y = 0.5
    # moved_pose.position.z = 0.2
    # move_to_target(moved_pose)


    # Άνοιγμα του gripper
    hand_command_pub.publish("open")

    # Επιστροφή στην αρχική θέση
    move_home()



def callback_fn(msg):
    global move_group, hand_command_pub
    if msg.data == "home":
        move_home()
    elif msg.data == "danai":
       move_danai()

def main():
    global move_group, hand_command_pub
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.Subscriber("/move_command", String, callback_fn)
    rospy.init_node("moveit_tutorial", anonymous=True)
    hand_command_pub = rospy.Publisher('/hand_command', String, queue_size=10)
    rospy.Subscriber("/move_commands", String, callback_fn)

    move_home()

    rospy.spin()

if __name__ == '__main__':
     main()



# #Ορίζω συντεταγμένες θέσης του υφάσματος
#
# FABRIC_POSITION = {'x': 0.4,
#                    'y': 0.2,
#                    'z': 0.5
#
# }
#
#
# #Ορίζω τη θέση για τη μετακίνηση του υφάσματος μισό μέτρο δίπλα (στον άξονα y)
#
# TARGET_POSITION = FABRIC_POSITION.copy()
# TARGET_POSITION['y'] += 0.5
#
#
# def move_arm_to_position(position):
#     pose_goal = Pose()
#     pose_goal.position.x = position['x']
#     pose_goal.position.y = position['y']
#     pose_goal.position.z = position['z']
#     pose_goal.orientation = move_group.get_current_pose().pose.orientation
#
#     move_group.set_pose_target(pose_goal)
#     move_group.go(wait=True)
#     move_group.stop()
#     move_group.clear_pose_targets()
# def callback_fn(msg):
#     if msg.data == 'danai':
#         rospy.loginfo("Moving arm to fabric position")
#         move_arm_to_position(FABRIC_POSITION)
#         rospy.sleep(2)
#
#         hand_command_pub.publish("close")
#         rospy.sleep(2)




#
#
# #Ορίζω τη θέση για τη μετακίνηση του υφάσματος μισό μέτρο δίπλα (στον άξονα y)
#
# TARGET_POSITION = FABRIC_POSITION.copy()
# TARGET_POSITION['y'] += 0.5
#
#
# def move_arm_to_position(position):
#     pose_goal = Pose()
#     pose_goal.position.x = position['x']
#     pose_goal.position.y = position['y']
#     pose_goal.position.z = position['z']
#     pose_goal.orientation = move_group.get_current_pose().pose.orientation
#
#     move_group.set_pose_target(pose_goal)
#     move_group.go(wait=True)
#     move_group.stop()
#     move_group.clear_pose_targets()
# def callback_fn(msg):
#     if msg.data == 'danai':
#         rospy.loginfo("Moving arm to fabric position")
#         move_arm_to_position(FABRIC_POSITION)
#         rospy.sleep(2)
#
#         hand_command_pub.publish("close")
#         rospy.loginfo("Moving arm with fabric")  # Μετακινώ τον βραχίονα με το ύφασμα στη νέα θέση
#
#         move_arm_to_position(TARGET_POSITION)
#         rospy.sleep(2)
#
#         hand_command_pub.publish("open")
#
#     elif msg.data == 'home':
#          rospy.loginfo("Moving arm to home position")
#          move_group.set_named_target("home")
#          plan = move_group.plan()
#          move_group.go(wait=True)
#          move_group.stop()
#          move_group.clear_pose_targets()



# def callback_fn(msg):
#     if msg.data == 'danai':
#         pose_goal = Pose()
#         pose_goal.position.x = 0.55
#         pose_goal.position.y = 0.04
#         pose_goal.position.z = 0.52
#         pose_goal.orientation.x = 0.471
#         pose_goal.orientation.y = 0.527
#         pose_goal.orientation.z = 0.527
#         pose_goal.orientation.w = 0.471
#         move_group.set_pose_target(pose_goal)
#         plan = move_group.plan()
#         plan = move_group.go(wait=True)
#         move_group.stop()
#         move_group.clear_pose_targets()
#
#         pose_goal = Pose()
#         pose_goal.position.x = 0.50
#         pose_goal.position.y = 0.03
#         pose_goal.position.z = 0.50
#         pose_goal.orientation.x = 0.471
#         pose_goal.orientation.y = 0.527
#         pose_goal.orientation.z = 0.527
#         pose_goal.orientation.w = 0.471
#         move_group.set_pose_target(pose_goal)
#         plan = move_group.plan()
#         plan = move_group.go(wait=True)
#         move_group.stop()
#         move_group.clear_pose_targets()
#
#         time.sleep(2)

    #     print("============ Target joint state")
    #     joint_goal = move_group.get_current_joint_values()
    #     joint_goal[0] = pi / 2
    #     joint_goal[1] = pi
    #     joint_goal[2] = 2.3
    #     joint_goal[3] = pi
    #     joint_goal[4] = 2.3
    #     joint_goal[5] = pi / 2
    #     move_group.go(joint_goal, wait=True)
    #     move_group.stop()
    # if msg.data == 'home':
    #     move_group.set_named_target("home")
    #     plan = move_group.plan()
    #     move_group.go(wait=True)
    #     move_group.stop()
    #     move_group.clear_pose_targets()
    #     hand_command_pub.publish("close")




# def callback_fn(msg):
#     if msg.data == 'danai':
#         pose_goal = Pose()
#         pose_goal.position.x = 0.55
#         pose_goal.position.y = 0.04
#         pose_goal.position.z = 0.52
#         pose_goal.orientation.x = 0.471
#         pose_goal.orientation.y = 0.527
#         pose_goal.orientation.z = 0.527
#         pose_goal.orientation.w = 0.471
#         move_group.set_pose_target(pose_goal)
#         plan = move_group.plan()
#         plan = move_group.go(wait=True)
#         move_group.stop()
#         move_group.clear_pose_targets()
#
#         pose_goal = Pose()
#         pose_goal.position.x = 0.50
    #
    #     print("============ Cartesian trajectory")
    #     waypoints = []
    #     wpose = move_group.get_current_pose().pose
    #     wpose.position.z += 0.5  # First move up (z)
    #     waypoints.append(copy.deepcopy(wpose))
    #     (plan, fraction) = move_group.compute_cartesian_path(
    #         waypoints, 0.01, 0.0  # waypoints to follow  # eef_step
    #     )  # jump_threshold
    #     move_group.execute(plan, wait=True)
    #
    #     joint_goal = move_group.get_current_joint_values()
    #     joint_goal[0] = -pi / 6
    #     move_group.go(joint_goal, wait=True)
    #     move_group.stop()
    #
    #     waypoints = []
    #     wpose = move_group.get_current_pose().pose
    #     wpose.position.z -= 0.5  # First move up (z)
    #     waypoints.append(copy.deepcopy(wpose))
    #     (plan, fraction) = move_group.compute_cartesian_path(
    #         waypoints, 0.01, 0.0  # waypoints to follow  # eef_step
    #     )  # jump_threshold
    #     move_group.execute(plan, wait=True)




moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node("moveit_tutorial", anonymous=True)

hand_command_pub = rospy.Publisher('/hand_command', String, queue_size=10)

robot = moveit_commander.RobotCommander()

scene = moveit_commander.PlanningSceneInterface()

move_group = moveit_commander.MoveGroupCommander("manipulator")

# move_group_gripper = moveit_commander.MoveGroupCommander("gripper")

# pub = rospy.Subscriber('/arm_commands', String, callback_fn)

print("============ Printing robot state")
print(robot.get_current_state())
print(move_group.get_current_pose().pose)

# print("============ Target joint state")
# joint_goal = move_group.get_current_joint_values()
# joint_goal[0] = pi/2
# joint_goal[1] = pi
# joint_goal[2] = 2.3
# joint_goal[3] = pi
# joint_goal[4] = 2.3
# joint_goal[5] = pi/2
# joint_goal[6] = 0
# move_group.go(joint_goal, wait=True)
# move_group.stop()
#
# print("============ Printing robot state")
# print(robot.get_current_state())
# print(move_group.get_current_pose().pose)

# print("============ Target pose")
# print(move_group.get_current_pose().pose)
# pose_goal = Pose()
# pose_goal.position.x = 0.50
# pose_goal.position.y = 0.03
# pose_goal.position.z = 0.50
# pose_goal.orientation.x = 0.471
# pose_goal.orientation.y = 0.527
# pose_goal.orientation.z = 0.527
# pose_goal.orientation.w = 0.471
# move_group.set_pose_target(pose_goal)
# plan = move_group.plan()
# plan = move_group.go(wait=True)
# move_group.stop()
# move_group.clear_pose_targets()

# print("============ Named pose")
# move_group.set_named_target("Home")
# plan = move_group.plan()
# move_group.go(wait=True)
# move_group.stop()
# move_group.clear_pose_targets()


# print("============ Cartesian trajectory")
# waypoints = []
# wpose = move_group.get_current_pose().pose
# wpose.position.z += 0.3  # First move up (z)
# wpose.position.x += 0.3  # and forward (x)
# waypoints.append(copy.deepcopy(wpose))
# wpose.position.y += 0.3  # Second move sideways (y)
# waypoints.append(copy.deepcopy(wpose))
# wpose.position.y -= 0.3  # Third move backwards (x)
# waypoints.append(copy.deepcopy(wpose))
# (plan, fraction) = move_group.compute_cartesian_path(
#     waypoints, 0.01, 0.0  # waypoints to follow  # eef_step
# )  # jump_threshold
# move_group.execute(plan, wait=True)
#
# print("============ Named pose")
# move_group.set_named_target("Home")
# plan = move_group.plan()
# move_group.go(wait=True)
# move_group.stop()
# move_group.clear_pose_targets()


rospy.spin()


